
12 February 2010
lee.margetts@manchester.ac.uk

p129g example input deck
------------------------

This example is very similar to the one in Smith and Griffiths 4th Edition.
The only differences are:

 o The point load has been replaced with a line load.
 o The material properties are more realistic, giving a reasonable displacement.

